window.PORTFOLIO_DATA={
  services:[
    ['01','Frontend Development','Building modern, responsive and interactive websites and web applications.'],
    ['02','Responsive Web Design','Creating experiences that work beautifully across smartphones, tablets and desktops.'],
    ['03','UI Development','Turning ideas and designs into polished, accessible user interfaces.'],
    ['04','Website Development','Building fast, functional and scalable websites with maintainable foundations.'],
    ['05','SEO-Friendly Development','Using semantic structure, performance optimization and practical SEO best practices.'],
    ['06','Performance Optimization','Improving speed, responsiveness, Core Web Vitals and overall user experience.'],
    ['07','Frontend Development Training','Hands-on learning through practical coding exercises, real-world projects and portfolio work.'],
    ['08','Technical Collaboration','Working with developers, startups, organizations and teams to build digital products.']
  ],
  projects:[
    {name:'Nova Business Landing',category:'Landing Pages',description:'Conversion-focused business landing experience with responsive sections and clear CTA hierarchy.',tech:['HTML','CSS','JavaScript']},
    {name:'EduCore School Portal',category:'School Websites',description:'Clean school information and admissions interface designed for mobile-first browsing.',tech:['HTML','CSS','JavaScript']},
    {name:'Apex Commerce UI',category:'Web Applications',description:'Modern storefront dashboard concept with product discovery, filters and responsive UI.',tech:['React','JavaScript','CSS']},
    {name:'Vertex Agency Site',category:'Business Websites',description:'Premium agency website concept balancing editorial typography, performance and motion.',tech:['HTML','CSS','SEO']},
    {name:'Pulse Portfolio UI',category:'UI Designs',description:'Minimal developer portfolio interface system with reusable cards and content modules.',tech:['UI','CSS','Responsive']},
    {name:'CloudDesk Dashboard',category:'Web Applications',description:'Responsive SaaS dashboard concept with accessible navigation and information hierarchy.',tech:['React','UI','Performance']},
    {name:'FinEdge Product Page',category:'Websites',description:'High-trust product page concept with responsive content blocks and fast-loading visuals.',tech:['HTML','CSS','SEO']},
    {name:'LaunchKit Microsite',category:'Other',description:'Compact product launch microsite built around speed, clarity and mobile usability.',tech:['JavaScript','CSS','Web Performance']}
  ],
  socials:{Facebook:'https://facebook.com/',X:'https://x.com/',GitHub:'https://github.com/',LinkedIn:'https://linkedin.com/'}
};
