window.Components={
  serviceCard(item){return `<article class="service-card reveal"><span class="service-index">${item[0]}</span><h3>${item[1]}</h3><p>${item[2]}</p></article>`},
  projectCard(project,index){return `<article class="project-card reveal"><div class="project-image" aria-hidden="true"><div class="project-art"></div></div><div class="project-body"><div class="project-meta"><span>${project.category}</span><span>0${(index%9)+1}</span></div><h3>${project.name}</h3><p>${project.description}</p><div class="tech-list">${project.tech.map(t=>`<span>${t}</span>`).join('')}</div><div class="project-links"><a href="#contact">View Project ↗</a><a href="#contact">GitHub ↗</a></div></div></article>`},
  socialLinks(socials){return Object.entries(socials).map(([name,url])=>`<a href="${url}" target="_blank" rel="noopener noreferrer" aria-label="${name}">${name==='X'?'𝕏':name[0]}</a>`).join('')}
};
