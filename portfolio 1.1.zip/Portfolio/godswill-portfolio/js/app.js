(() => {
  const $=(s,root=document)=>root.querySelector(s), $$=(s,root=document)=>[...root.querySelectorAll(s)];
  const WA='2348036359839';
  const data=window.PORTFOLIO_DATA;

  // Render data-driven sections.
  $('#services-grid').innerHTML=data.services.map(Components.serviceCard).join('');
  $('#social-links').innerHTML=Components.socialLinks(data.socials);
  const categories=['All',...new Set(data.projects.map(p=>p.category))];
  $('.project-filters').innerHTML=categories.map((c,i)=>`<button class="filter-btn ${i===0?'active':''}" type="button" data-filter="${c}">${c}</button>`).join('');
  const renderProjects=(filter='All')=>{$('#project-grid').innerHTML=data.projects.filter(p=>filter==='All'||p.category===filter).map(Components.projectCard).join('');observeReveals();};
  renderProjects();
  $$('.filter-btn').forEach(btn=>btn.addEventListener('click',()=>{$$('.filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');renderProjects(btn.dataset.filter)}));

  // Mobile navigation + active link.
  const header=$('.site-header'),toggle=$('.nav-toggle'),menu=$('#primary-menu');
  const closeMenu=()=>{menu.classList.remove('open');toggle.setAttribute('aria-expanded','false')};
  toggle.addEventListener('click',()=>{const open=!menu.classList.contains('open');menu.classList.toggle('open',open);toggle.setAttribute('aria-expanded',String(open));});
  $$('.nav-link, .nav-cta',menu).forEach(a=>a.addEventListener('click',closeMenu));
  const sections=$$('main section[id]');
  const navObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){const link=$(`.nav-link[href="#${entry.target.id}"]`);if(link){$$('.nav-link').forEach(l=>l.classList.remove('active'));link.classList.add('active')}}}),{rootMargin:'-35% 0px -55% 0px'});
  sections.forEach(s=>navObserver.observe(s));
  const onScroll=()=>{header.classList.toggle('scrolled',scrollY>20);$('#to-top').classList.toggle('show',scrollY>650)};addEventListener('scroll',onScroll,{passive:true});onScroll();
  $('#to-top').addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));

  // Lightweight reveal observer.
  let revealObserver;
  function observeReveals(){if(revealObserver) revealObserver.disconnect();revealObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');revealObserver.unobserve(e.target)}}),{threshold:.08});$$('.reveal').forEach(el=>revealObserver.observe(el));}
  observeReveals();

  // Counters.
  const counters=$$('[data-counter]');
  const counterObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(!entry.isIntersecting)return;const el=entry.target,target=Number(el.dataset.counter),suffix=el.dataset.suffix||'';let start=0;const duration=900,startTime=performance.now();const tick=now=>{const p=Math.min((now-startTime)/duration,1);el.textContent=Math.round(target*(1-Math.pow(1-p,3)))+suffix;if(p<1)requestAnimationFrame(tick)};requestAnimationFrame(tick);counterObserver.unobserve(el)}),{threshold:.6});counters.forEach(c=>counterObserver.observe(c));

  // Accessible, touch-friendly image carousel.
  const slides=$$('.slide'),dots=$('.slider-dots'),count=$('#slide-count');let current=0,timer;
  slides.forEach((_,i)=>{const b=document.createElement('button');b.className='slider-dot'+(i===0?' active':'');b.type='button';b.setAttribute('aria-label',`Show image ${i+1}`);b.setAttribute('role','tab');b.addEventListener('click',()=>go(i,true));dots.appendChild(b)});
  const update=()=>{slides.forEach((s,i)=>s.classList.toggle('active',i===current));$$('.slider-dot').forEach((d,i)=>{d.classList.toggle('active',i===current);d.setAttribute('aria-selected',String(i===current))});count.textContent=`0${current+1} / 04`};
  const go=(i,user=false)=>{current=(i+slides.length)%slides.length;update();if(user)restart()};
  const restart=()=>{clearInterval(timer);timer=setInterval(()=>go(current+1),5000)};
  $('#prev-slide').addEventListener('click',()=>go(current-1,true));$('#next-slide').addEventListener('click',()=>go(current+1,true));$('.slider-stage').addEventListener('mouseenter',()=>clearInterval(timer));$('.slider-stage').addEventListener('mouseleave',restart);$('.slider-stage').addEventListener('focusin',()=>clearInterval(timer));$('.slider-stage').addEventListener('focusout',restart);restart();
  let touchX=0;$('.slider-stage').addEventListener('touchstart',e=>touchX=e.changedTouches[0].clientX,{passive:true});$('.slider-stage').addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-touchX;if(Math.abs(dx)>45)go(current+(dx<0?1:-1),true)},{passive:true});

  // Enrollment modal.
  const modal=$('#enroll-modal'),openModal=()=>{modal.hidden=false;document.body.style.overflow='hidden';setTimeout(()=>$('input',modal)?.focus(),20)},closeModal=()=>{modal.hidden=true;document.body.style.overflow=''};
  $('#enroll-btn').addEventListener('click',openModal);$('#close-modal').addEventListener('click',closeModal);modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)closeModal()});
  const laptop=$$('#enroll-form input[name="laptop"]'),mobileQ=$('#mobile-question'),message=$('#enroll-message');
  laptop.forEach(r=>r.addEventListener('change',()=>{const no=$('input[name="laptop"]:checked')?.value==='No';mobileQ.hidden=!no;if(!no)$$('input[name="mobile"]').forEach(x=>x.checked=false);message.textContent=no?'Please select whether you have a good mobile phone.':''}));
  $('#enroll-form').addEventListener('submit',e=>{e.preventDefault();const form=e.currentTarget;if(!form.checkValidity()){form.reportValidity();return}const fd=new FormData(form),laptopValue=fd.get('laptop'),mobileValue=laptopValue==='No'?(fd.get('mobile')||'Not selected'):'Not Applicable';const text=`Hello Godswill, I would like to enroll in your Frontend Development Training.\n\nFull Name: ${fd.get('fullName')}\nPhone Number: ${fd.get('phone')}\nEmail: ${fd.get('email')}\nLaptop: ${laptopValue}\nGood Mobile Phone: ${mobileValue}\n\nI would like to know more about the training.`;window.open(`https://wa.me/${WA}?text=${encodeURIComponent(text)}`,'_blank','noopener,noreferrer');message.textContent='WhatsApp is opening with your enrollment details.'});

  // Contact form: honest mailto handoff, no fake backend.
  $('#contact-form').addEventListener('submit',e=>{e.preventDefault();const form=e.currentTarget;if(!form.checkValidity()){form.reportValidity();return}const fd=new FormData(form),subject=encodeURIComponent(fd.get('subject')),body=encodeURIComponent(`Name: ${fd.get('name')}\nEmail: ${fd.get('email')}\n\n${fd.get('message')}`);window.location.href=`mailto:goodwillemmanuel7@gmail.com?subject=${subject}&body=${body}`;$('#contact-status').textContent='Your email app should open with the message prepared.'});

  // Pointer glow only on fine pointers; no animation loop.
  const glow=$('.cursor-glow');if(matchMedia('(pointer:fine)').matches&&!matchMedia('(prefers-reduced-motion: reduce)').matches){addEventListener('pointermove',e=>{glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px'},{passive:true})}

  // Make the canonical URL concrete after deployment without inventing a domain.
  const canonical=$('link[rel="canonical"]');if(canonical)canonical.href=location.href.split('#')[0];
})();
