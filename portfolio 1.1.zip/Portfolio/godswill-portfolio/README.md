# Godswill Eze Emmanuel — Portfolio

A zero-dependency, performance-focused personal portfolio built with semantic HTML, modern CSS and modular vanilla JavaScript.

## Run locally

Because the site is static, no Node dependency install is required.

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

## Customize

- `js/data.js` — services, project data and social URLs.
- `assets/` — replace the four portrait WebP files with optimized images using the same filenames.
- `index.html` — update SEO copy and contact details if needed.
- `styles.css` — edit the design tokens in `:root` for global colors, spacing and radius.

## Deployment

Upload the project folder to any static host (GitHub Pages, Netlify, Vercel, Cloudflare Pages, traditional hosting, etc.). After deployment, the canonical URL is set to the live page URL by JavaScript; for strongest crawler compatibility, replace the relative canonical in `index.html` with your final HTTPS domain once you have it.

## Notes

- WhatsApp CTAs use `https://wa.me/2348036359839`.
- Contact form uses a transparent `mailto:` handoff rather than pretending a backend submission succeeded.
- Social links are placeholders in `js/data.js` and should be replaced with the actual profiles.
- Project Live Demo/GitHub links are placeholders pointing to the contact section until real project URLs are supplied.
