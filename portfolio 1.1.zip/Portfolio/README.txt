GODSWILL EZE EMMANUEL PORTFOLIO

Files:
- index.html
- style.css
- script.js
- assets/profile-1.png
- assets/profile-2.png

Open index.html in a browser to preview the site.

To customize:
1. Replace the social URLs at the top of script.js.
2. Edit the projects array in script.js.
3. Replace the placeholder third/fourth slider images in index.html.
4. Change https://yourdomain.com/ in index.html to your real domain.
5. For production SEO, also create robots.txt and sitemap.xml for your actual domain.

WhatsApp:
+2348036359839

The enrollment and contact forms open WhatsApp with the submitted information. No backend is required for this version.
