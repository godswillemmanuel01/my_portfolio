const WHATSAPP = "2348036359839";

/* Replace these with your real social profile URLs */
const SOCIAL_LINKS = {
  facebook: "https://facebook.com/",
  x: "https://x.com/",
  github: "https://github.com/",
  linkedin: "https://linkedin.com/"
};

/* Add/edit your real projects here. */
const projects = [
  {
    title: "Blog Site",
    category: "websites",
    description: "A modern blog experience for sharing thoughtful content and stories online.",
    tags: ["HTML", "CSS", "JavaScript"],
    url: "https://godswillblog.netlify.app/",
    image: "assets/blog-site-preview.svg"
  },
  {
    title: "ObiBest",
    category: "websites",
    description: "A polished brand website focused on a clean interface, smooth responsiveness, and a strong online presence.",
    tags: ["HTML", "CSS", "JavaScript"],
    url: "https://obibest.netlify.app/",
    image: "https://image.thum.io/get/width/1200/https://obibest.netlify.app/"
  },
  {
    title: "Modern Business Website",
    category: "websites",
    description: "A responsive business website with a clean technology-focused interface.",
    tags: ["HTML", "CSS", "JavaScript"]
  },
  {
    title: "Dashboard Interface",
    category: "web-apps",
    description: "A responsive dashboard concept designed for efficient data and workflow management.",
    tags: ["JavaScript", "UI", "Responsive"]
  },
  {
    title: "Tech Landing Page",
    category: "landing",
    description: "A conversion-focused landing page with a premium futuristic visual system.",
    tags: ["HTML", "CSS", "UI"]
  },
  {
    title: "Creative Portfolio",
    category: "websites",
    description: "A modern portfolio experience designed to showcase work and professional services.",
    tags: ["Frontend", "UI", "CSS"]
  },
  {
    title: "Mobile App UI",
    category: "ui-design",
    description: "A polished mobile interface concept with a strong visual hierarchy and clean components.",
    tags: ["UI Design", "UX", "Prototype"]
  },
  {
    title: "Web Application Concept",
    category: "web-apps",
    description: "A responsive application interface focused on usability and fast interaction.",
    tags: ["JavaScript", "Web App", "UI"]
  }
];

/* Mobile navigation */
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
});

document.querySelectorAll(".nav-link, .nav-talk").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

/* Header scroll state */
const header = document.getElementById("header");
window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 30);
}, { passive: true });

/* Lightweight cursor glow on devices with a mouse */
const cursorGlow = document.querySelector(".cursor-glow");
if (window.matchMedia("(pointer:fine)").matches) {
  window.addEventListener("pointermove", e => {
    cursorGlow.style.left = `${e.clientX}px`;
    cursorGlow.style.top = `${e.clientY}px`;
  }, { passive: true });
} else {
  cursorGlow.remove();
}

/* Scroll reveal */
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

/* Active navigation */
const sections = [...document.querySelectorAll("main section[id]")];
const navItems = [...document.querySelectorAll(".nav-link")];

const sectionObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    navItems.forEach(item => item.classList.toggle(
      "active",
      item.getAttribute("href") === `#${entry.target.id}`
    ));
  });
}, { rootMargin: "-35% 0px -55% 0px" });

sections.forEach(section => sectionObserver.observe(section));

/* Image slider */
const slides = [...document.querySelectorAll(".slide")];
const dotsWrap = document.getElementById("sliderDots");
let currentSlide = 0;
let sliderTimer;

slides.forEach((_, index) => {
  const dot = document.createElement("button");
  dot.className = `dot ${index === 0 ? "active" : ""}`;
  dot.setAttribute("aria-label", `Go to image ${index + 1}`);
  dot.addEventListener("click", () => showSlide(index));
  dotsWrap.appendChild(dot);
});

const dots = [...dotsWrap.children];

function showSlide(index) {
  currentSlide = (index + slides.length) % slides.length;
  slides.forEach((slide, i) => slide.classList.toggle("active", i === currentSlide));
  dots.forEach((dot, i) => dot.classList.toggle("active", i === currentSlide));
}

function restartSlider() {
  clearInterval(sliderTimer);
  sliderTimer = setInterval(() => showSlide(currentSlide + 1), 5000);
}

document.getElementById("prevSlide").addEventListener("click", () => {
  showSlide(currentSlide - 1);
  restartSlider();
});
document.getElementById("nextSlide").addEventListener("click", () => {
  showSlide(currentSlide + 1);
  restartSlider();
});
restartSlider();

/* Project rendering */
const projectGrid = document.getElementById("projectGrid");
const filters = document.querySelectorAll(".filter");

function showProjectUnavailable() {
  alert("Project server is down at the moment!");
}

function renderProjects(filter = "all") {
  projectGrid.innerHTML = "";

  projects
    .filter(project => filter === "all" || project.category === filter)
    .forEach(project => {
      const card = document.createElement("article");
      card.className = "project-card reveal visible";
      const hasLiveProject = Boolean(project.url && project.url.trim() !== "");
      const imageMarkup = project.image
        ? `<img src="${project.image}" alt="Preview of ${project.title}" loading="lazy">`
        : `<div class="project-unavailable-message">Project server is down at the moment!</div>`;
      const mediaMarkup = hasLiveProject
        ? `<a class="project-image-link" href="${project.url}" target="_blank" rel="noopener noreferrer">${imageMarkup}<span>${project.category.replace("-", " ").toUpperCase()}</span></a>`
        : `<button class="project-image-link project-unavailable" type="button" aria-label="Project unavailable">${imageMarkup}<span>${project.category.replace("-", " ").toUpperCase()}</span></button>`;

      const actionMarkup = hasLiveProject
        ? `<a href="${project.url}" target="_blank" rel="noopener noreferrer">View Project ↗</a>`
        : `<button class="project-link-btn project-unavailable" type="button">Project server is down at the moment!</button>`;

      card.innerHTML = `
        <div class="project-image${project.image ? " has-image" : ""}">
          ${mediaMarkup}
        </div>
        <div class="project-body">
          <h3>${project.title}</h3>
          <p>${project.description}</p>
          <div class="tags">${project.tags.map(tag => `<span>${tag}</span>`).join("")}</div>
          <div class="project-actions">
            ${actionMarkup}
            <a href="${SOCIAL_LINKS.github}" target="_blank" rel="noopener">GitHub ↗</a>
          </div>
        </div>
      `;

      card.querySelectorAll(".project-unavailable").forEach(button => {
        button.addEventListener("click", (event) => {
          event.preventDefault();
          showProjectUnavailable();
        });
      });

      projectGrid.appendChild(card);
    });
}

renderProjects();

filters.forEach(button => {
  button.addEventListener("click", () => {
    filters.forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    renderProjects(button.dataset.filter);
  });
});

/* Counter animation */
const counters = document.querySelectorAll("[data-count]");
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;

    const el = entry.target;
    const target = Number(el.dataset.count);
    const duration = 900;
    const start = performance.now();

    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(target * eased) + (target === 50 ? "+" : "+");
      if (progress < 1) requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
    counterObserver.unobserve(el);
  });
}, { threshold: .7 });

counters.forEach(counter => counterObserver.observe(counter));

/* Enrollment modal */
const modal = document.getElementById("enrollModal");
const enrollBtn = document.getElementById("enrollBtn");
const modalClose = document.getElementById("modalClose");
const modalBackdrop = document.getElementById("modalBackdrop");
const enrollForm = document.getElementById("enrollForm");
const phoneQuestion = document.getElementById("phoneQuestion");
const deviceNotice = document.getElementById("deviceNotice");

function openModal() {
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  setTimeout(() => document.getElementById("fullName").focus(), 50);
}

function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
}

enrollBtn.addEventListener("click", openModal);
modalClose.addEventListener("click", closeModal);
modalBackdrop.addEventListener("click", closeModal);
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
});

/* Enrollment device logic */
document.querySelectorAll('input[name="laptop"]').forEach(input => {
  input.addEventListener("change", () => {
    const hasLaptop = input.value === "Yes";
    phoneQuestion.classList.toggle("show", !hasLaptop);

    if (hasLaptop) {
      deviceNotice.classList.remove("show");
      document.querySelectorAll('input[name="mobile"]').forEach(radio => radio.checked = false);
    }
  });
});

document.querySelectorAll('input[name="mobile"]').forEach(input => {
  input.addEventListener("change", () => {
    deviceNotice.classList.toggle("show", input.value === "No");
  });
});

/* Enrollment -> WhatsApp */
enrollForm.addEventListener("submit", e => {
  e.preventDefault();

  const name = document.getElementById("fullName").value.trim();
  const phone = document.getElementById("phoneNumber").value.trim();
  const email = document.getElementById("emailAddress").value.trim();
  const laptop = document.querySelector('input[name="laptop"]:checked')?.value || "Not selected";
  const mobile = document.querySelector('input[name="mobile"]:checked')?.value || "Not applicable";

  const message =
`Hello Godswill, I would like to enroll in your Frontend Development Training.

Full Name: ${name}
Phone Number: ${phone}
Email: ${email}
Laptop: ${laptop}
Good Mobile Phone: ${mobile}

I would like to receive more information about the training.`;

  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
});

/* Contact form -> WhatsApp */
document.getElementById("contactForm").addEventListener("submit", e => {
  e.preventDefault();

  const name = document.getElementById("contactName").value.trim();
  const email = document.getElementById("contactEmail").value.trim();
  const subject = document.getElementById("contactSubject").value.trim();
  const message = document.getElementById("contactMessage").value.trim();

  const whatsappMessage =
`Hello Godswill,

My name is ${name}.
Email: ${email}
Subject: ${subject}

Message:
${message}`;

  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(whatsappMessage)}`, "_blank", "noopener");
});

/* Keep social URLs centralized */
document.querySelectorAll(".socials a").forEach(link => {
  const label = link.getAttribute("aria-label");
  if (label.includes("Facebook")) link.href = SOCIAL_LINKS.facebook;
  if (label.includes("X /")) link.href = SOCIAL_LINKS.x;
  if (label.includes("GitHub")) link.href = SOCIAL_LINKS.github;
  if (label.includes("LinkedIn")) link.href = SOCIAL_LINKS.linkedin;
});
